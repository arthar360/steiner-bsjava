/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mulinh;

/**
 *
 * @author SRCOEM
 */
public class Mulinh {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        bankaccount a = new bankaccount(
                                        12135151,
                                        80000,
                                        "Susbham",
                                        2.5,
                                        1);
        
        fixdepacc f = new fixdepacc(
                                        12135151,
                                        80000,
                                        "Susyash",
                                        1.5,
                                        1);
        savacc s = new savacc(
                                        12135151,
                                        80000,
                                        "Sustyam",
                                        2.5);
        
        
       System.out.println("THE AMOUNT AFTER DEPOSITING 5000 :" + a.deposit(5000));
       System.out.println("CLOSING ACC AND DISPLAYING BALANCE :" + a.closeacc());
       System.out.println("INITIAL RATE OF INTEREST (a) :" + a.roi);
       a.updateint();
       System.out.println("FINAL RATE OF INTEREST (a) :" +a.roi);
       System.out.println("INITIAL RATE OF INTEREST (f) :" +f.roi);
       f.updateint();
       System.out.println("FINAL RATE OF INTEREST (f) :" +f.roi);
       System.out.println("CLOSING ACCOUNT AND DISPLAYING BALANCE (f):" + f.closeacc());
       
       System.out.println("WITHDRAWING 5000 FROM SAVINGS ACCONT :" + s.withdraw(5000));
    }
    
}
