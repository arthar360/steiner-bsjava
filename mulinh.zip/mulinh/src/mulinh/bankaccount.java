/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mulinh;
import java.util.Random;

/**
 *
 * @author SRCOEM
 */
public class bankaccount {
    int  accno, adhno, bal, actype;
    String owname;
    double roi;
    double yr;
    bankaccount( int ad, int b, String ow, double y, int act)
    {
        Random r = new Random();
        actype = act;
        yr = y;
        if(act == 1)
        {
            accno = 11000 + r.ints(100, 1000).findFirst().getAsInt();
        }
        else if(act == 2)
        {
            accno = 22000 + r.ints(100, 1000).findFirst().getAsInt();
        }
        adhno = ad;
        if(act == 1)
        {
            roi = 0.04;
        }
        else if(act == 2)
        {
            if((y > 1) && (y < 2))
            {
                roi = 0.06;
            }
            else if((y > 2) && (y < 5))
            {
                roi = 0.065;
            }
            else if(y > 5)
            {
                roi = 0.07;
            }
        }
        bal = b;
        owname = ow;
    }
    int deposit(int amt)
    {
            bal += amt;
            return bal;
    }
    
    double closeacc()
    {
            double t = bal;
            bal = 0;
            System.out.println("THE ACCOUNT IS CLOSED.");
            return t;
    }
    
    void updateint()
    {
            bal+=(0.04)*bal;
            System.out.println("THE NEW BALANCE IS :" + bal);
    }
}

interface debitable{
    int withdraw(int amount);
}

class fixdepacc extends bankaccount{
    double lip;
    double clyr;
    fixdepacc(int ad, int b, String ow, double l, double clyr)
    {
        super(ad,b,ow,l,2);        
        lip = l;
        this.clyr = clyr;
    }
    
    @Override
    void updateint()
    {
        if(lip > yr)
        {
            if((lip > 1) && (lip < 2))
            {
                roi = 0.06;
            }
            else if((lip > 2) && (lip < 5))
            {
                roi = 0.065;
            }
            else if(lip > 5)
            {
                roi = 0.07;
            } 
        }
    }
    
    double closacc()
    {
            double t = 0;
            if(clyr < lip)
            {
                t = bal - (0.05)*bal;
                
            }
            else{
                t = bal;
            }
            bal = 0;
            System.out.println("THE ACCOUNT IS CLOSED.");
            return t;
    }
    
}

class savacc extends bankaccount implements debitable
{
    savacc( int ad, int b, String ow, double y)
    {
        super(ad,b,ow,y,1);
    }
    
    public int withdraw(int amount)
    {
        bal -= amount;
        return bal;
    }
}